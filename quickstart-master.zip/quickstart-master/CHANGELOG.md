<a name="0.1.12"></a>
# 0.1.12 (2016-03-23)
* update packages
  * Angular 2 beta 12
  * zones 0.6.6
* remove es6-promise because no longer needed.

<a name="0.1.11"></a>
# 0.1.11 (2016-03-18)
* update packages
  * Angular 2 beta 11
  * zones 0.6.4
  * typescript 1.8.9
  * typings 0.7.9